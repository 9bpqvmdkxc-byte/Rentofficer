"use client";

import { useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { signIn } from "next-auth/react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { Car, Loader2 } from "lucide-react";

function LoginForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const isSuperAdmin = searchParams.get("type") === "superadmin";

  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);

    try {
      const res = await signIn("credentials", {
        email,
        password,
        userType: isSuperAdmin ? "superadmin" : "company",
        redirect: false,
      });

      if (res?.error) {
        toast.error("Giriş başarısız", { description: "E-posta veya şifre hatalı" });
        setLoading(false);
        return;
      }

      toast.success("Giriş başarılı");
      // Session'ın güncellenmesi için kısa bekleme
      setTimeout(() => {
        if (isSuperAdmin) {
          router.push("/superadmin");
        } else {
          router.push("/");
          router.refresh();
        }
      }, 500);
    } catch (error) {
      toast.error("Bir hata oluştu");
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-br from-primary/5 to-muted">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-3">
            <div className="h-12 w-12 rounded-xl bg-primary flex items-center justify-center">
              <Car className="h-7 w-7 text-primary-foreground" />
            </div>
          </div>
          <CardTitle>{isSuperAdmin ? "Platform Girişi" : "Firma Girişi"}</CardTitle>
          <CardDescription>
            {isSuperAdmin ? "Süper admin hesabınızla giriş yapın" : "Hesabınıza giriş yapın"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="email">E-posta</Label>
              <Input
                id="email"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="ornek@firma.com"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Şifre</Label>
              <Input
                id="password"
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            <Button type="submit" className="w-full" disabled={loading}>
              {loading && <Loader2 className="h-4 w-4 animate-spin" />}
              Giriş Yap
            </Button>
          </form>

          <div className="mt-6 text-center text-sm space-y-2">
            {!isSuperAdmin && (
              <p>
                Hesabın yok mu?{" "}
                <Link href="/register" className="text-primary hover:underline font-medium">
                  Kayıt ol
                </Link>
              </p>
            )}
            <p className="text-muted-foreground">
              {isSuperAdmin ? (
                <Link href="/login" className="hover:underline">
                  Firma girişine dön
                </Link>
              ) : (
                <Link href="/login?type=superadmin" className="hover:underline">
                  Platform admin girişi
                </Link>
              )}
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center"><Loader2 className="h-6 w-6 animate-spin" /></div>}>
      <LoginForm />
    </Suspense>
  );
}
