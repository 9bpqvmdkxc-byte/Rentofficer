import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Car, Users, FileText, Wrench, DollarSign, Calendar, Check } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { formatCurrency } from "@/lib/utils";

export default async function HomePage() {
  const plans = await prisma.plan
    .findMany({
      where: { isActive: true },
      orderBy: { sortOrder: "asc" },
    })
    .catch(() => []);

  const features = [
    { icon: Car, title: "Araç Yönetimi", desc: "Tüm araçlarınızı tek panelden yönetin" },
    { icon: Users, title: "Müşteri Takibi", desc: "Cari hesap ve müşteri bilgileri" },
    { icon: FileText, title: "Sözleşmeler", desc: "Dijital kiralama sözleşmeleri" },
    { icon: Calendar, title: "Rezervasyon", desc: "Takvim görünümlü rezervasyon sistemi" },
    { icon: Wrench, title: "Bakım Takibi", desc: "Servis ve bakım planlaması" },
    { icon: DollarSign, title: "Finans", desc: "Gelir, gider ve kasa yönetimi" },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/30">
      {/* Nav */}
      <nav className="border-b bg-background/80 backdrop-blur sticky top-0 z-40">
        <div className="container flex h-16 items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <Car className="h-6 w-6 text-primary" />
            <span className="font-bold text-lg">Rent A Car SaaS</span>
          </Link>
          <div className="flex gap-3">
            <Button variant="ghost" asChild>
              <Link href="/login">Giriş Yap</Link>
            </Button>
            <Button asChild>
              <Link href="/register">Ücretsiz Başla</Link>
            </Button>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="container py-20 text-center">
        <h1 className="text-5xl md:text-6xl font-bold tracking-tight mb-6">
          Rent A Car İşletmeniz
          <span className="block text-primary mt-2">Tek Panelden</span>
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto mb-8">
          Araçlar, müşteriler, sözleşmeler, bakımlar ve finansınız — hepsi tek yerde, her cihazdan erişilebilir.
        </p>
        <div className="flex gap-3 justify-center">
          <Button size="lg" asChild>
            <Link href="/register">30 Gün Ücretsiz Dene</Link>
          </Button>
          <Button size="lg" variant="outline" asChild>
            <Link href="/login">Giriş Yap</Link>
          </Button>
        </div>
      </section>

      {/* Features */}
      <section className="container py-16">
        <h2 className="text-3xl font-bold text-center mb-12">Her şey dahil</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {features.map((f) => (
            <Card key={f.title}>
              <CardHeader>
                <div className="h-12 w-12 rounded-lg bg-primary/10 flex items-center justify-center mb-3">
                  <f.icon className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-xl">{f.title}</CardTitle>
                <CardDescription>{f.desc}</CardDescription>
              </CardHeader>
            </Card>
          ))}
        </div>
      </section>

      {/* Pricing */}
      {plans.length > 0 && (
        <section className="container py-16">
          <h2 className="text-3xl font-bold text-center mb-4">Paketler</h2>
          <p className="text-center text-muted-foreground mb-12">İşletmenize uygun planı seçin</p>
          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
            {plans.map((plan, idx) => (
              <Card key={plan.id} className={idx === 1 ? "border-primary shadow-lg scale-105" : ""}>
                <CardHeader>
                  <CardTitle>{plan.name}</CardTitle>
                  <CardDescription>{plan.description}</CardDescription>
                  <div className="pt-4">
                    <span className="text-4xl font-bold">
                      {formatCurrency(Number(plan.monthlyPrice), plan.currency)}
                    </span>
                    <span className="text-muted-foreground">/ay</span>
                  </div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 mb-6 text-sm">
                    <li className="flex gap-2">
                      <Check className="h-4 w-4 text-green-600 shrink-0 mt-0.5" />
                      <span>{plan.maxVehicles} araç</span>
                    </li>
                    <li className="flex gap-2">
                      <Check className="h-4 w-4 text-green-600 shrink-0 mt-0.5" />
                      <span>{plan.maxUsers} kullanıcı</span>
                    </li>
                    <li className="flex gap-2">
                      <Check className="h-4 w-4 text-green-600 shrink-0 mt-0.5" />
                      <span>{plan.maxBranches} şube</span>
                    </li>
                    {plan.hasMaintenance && (
                      <li className="flex gap-2">
                        <Check className="h-4 w-4 text-green-600 shrink-0 mt-0.5" />
                        <span>Bakım takibi</span>
                      </li>
                    )}
                    {plan.hasFinance && (
                      <li className="flex gap-2">
                        <Check className="h-4 w-4 text-green-600 shrink-0 mt-0.5" />
                        <span>Finans modülü</span>
                      </li>
                    )}
                    {plan.hasReports && (
                      <li className="flex gap-2">
                        <Check className="h-4 w-4 text-green-600 shrink-0 mt-0.5" />
                        <span>Raporlar</span>
                      </li>
                    )}
                    {plan.hasDamageReport && (
                      <li className="flex gap-2">
                        <Check className="h-4 w-4 text-green-600 shrink-0 mt-0.5" />
                        <span>Hasar raporu</span>
                      </li>
                    )}
                  </ul>
                  <Button className="w-full" variant={idx === 1 ? "default" : "outline"} asChild>
                    <Link href={`/register?plan=${plan.slug}`}>Seç</Link>
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="border-t py-8 mt-16">
        <div className="container text-center text-sm text-muted-foreground">
          © {new Date().getFullYear()} Rent A Car SaaS. Tüm hakları saklıdır.
        </div>
      </footer>
    </div>
  );
}
