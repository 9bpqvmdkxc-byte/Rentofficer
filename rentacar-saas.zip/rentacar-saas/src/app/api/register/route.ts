import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/prisma";

const registerSchema = z.object({
  companyName: z.string().min(2),
  companySlug: z.string().min(2).regex(/^[a-z0-9-]+$/),
  adminName: z.string().min(2),
  email: z.string().email(),
  phone: z.string().optional(),
  password: z.string().min(6),
  planSlug: z.string().default("starter"),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = registerSchema.safeParse(body);

    if (!parsed.success) {
      return NextResponse.json(
        { error: "Geçersiz veri", details: parsed.error.flatten() },
        { status: 400 }
      );
    }

    const { companyName, companySlug, adminName, email, phone, password, planSlug } = parsed.data;

    // Reserved slugları kontrol et
    const reserved = ["login", "register", "superadmin", "api", "admin", "dashboard", "_next"];
    if (reserved.includes(companySlug)) {
      return NextResponse.json({ error: "Bu URL kullanılamaz, farklı bir tane seçin" }, { status: 400 });
    }

    // Slug benzersiz mi?
    const existingCompany = await prisma.company.findUnique({ where: { slug: companySlug } });
    if (existingCompany) {
      return NextResponse.json({ error: "Bu firma URL'i zaten alınmış" }, { status: 400 });
    }

    // Plan var mı?
    const plan = await prisma.plan.findUnique({ where: { slug: planSlug } });
    if (!plan) {
      return NextResponse.json({ error: "Geçersiz plan" }, { status: 400 });
    }

    // 30 gün deneme
    const trialEndsAt = new Date();
    trialEndsAt.setDate(trialEndsAt.getDate() + 30);

    const hashedPassword = await bcrypt.hash(password, 10);

    // Transaction ile firma + şube + admin + abonelik + ayarları oluştur
    const company = await prisma.$transaction(async (tx) => {
      const newCompany = await tx.company.create({
        data: {
          slug: companySlug,
          name: companyName,
          email,
          phone,
          settings: {
            create: {
              contractPrefix: "SZL",
            },
          },
        },
      });

      await tx.subscription.create({
        data: {
          companyId: newCompany.id,
          planId: plan.id,
          status: "TRIAL",
          trialEndsAt,
          currentPeriodEnd: trialEndsAt,
        },
      });

      const mainBranch = await tx.branch.create({
        data: {
          companyId: newCompany.id,
          name: "Ana Şube",
          code: "MAIN",
          isMain: true,
        },
      });

      await tx.user.create({
        data: {
          companyId: newCompany.id,
          branchId: mainBranch.id,
          email,
          password: hashedPassword,
          name: adminName,
          phone,
          role: "COMPANY_ADMIN",
        },
      });

      // Varsayılan araç kategorileri
      const categories = ["Ekonomik", "Orta Sınıf", "SUV", "Lüks", "Ticari"];
      for (let i = 0; i < categories.length; i++) {
        await tx.vehicleCategory.create({
          data: { companyId: newCompany.id, name: categories[i], sortOrder: i },
        });
      }

      // Varsayılan gider kategorileri
      const expenses = ["Yakıt", "Temizlik", "Bakım", "Sigorta", "Kira", "Diğer"];
      for (const name of expenses) {
        await tx.expenseCategory.create({
          data: { companyId: newCompany.id, name },
        });
      }

      return newCompany;
    });

    return NextResponse.json({
      success: true,
      companyId: company.id,
      companySlug: company.slug,
    });
  } catch (error) {
    console.error("Register error:", error);
    return NextResponse.json({ error: "Kayıt sırasında bir hata oluştu" }, { status: 500 });
  }
}
