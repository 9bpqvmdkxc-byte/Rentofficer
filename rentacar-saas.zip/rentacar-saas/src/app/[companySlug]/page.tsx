import { prisma } from "@/lib/prisma";
import { notFound } from "next/navigation";
import { auth, signOut } from "@/lib/auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Car, Users, FileText, Calendar, LogOut, Building2 } from "lucide-react";

export default async function CompanyDashboard({
  params,
}: {
  params: Promise<{ companySlug: string }>;
}) {
  const { companySlug } = await params;
  const session = await auth();

  const company = await prisma.company.findUnique({
    where: { slug: companySlug },
    include: {
      subscription: { include: { plan: true } },
      _count: { select: { vehicles: true, customers: true, contracts: true, reservations: true } },
    },
  });

  if (!company) notFound();

  const user = (session?.user as any);

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="border-b bg-background">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary flex items-center justify-center">
              <Building2 className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <div className="font-bold">{company.name}</div>
              <div className="text-xs text-muted-foreground">/{company.slug}</div>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className="text-right text-sm">
              <div className="font-medium">{user?.name}</div>
              <div className="text-xs text-muted-foreground">{user?.role}</div>
            </div>
            <form action={async () => { "use server"; await signOut({ redirectTo: "/" }); }}>
              <Button variant="outline" size="sm" type="submit">
                <LogOut className="h-4 w-4" />
                Çıkış
              </Button>
            </form>
          </div>
        </div>
      </header>

      <div className="container py-8 space-y-6">
        {company.subscription && (
          <Card>
            <CardContent className="flex items-center justify-between py-4">
              <div>
                <div className="text-sm text-muted-foreground">Aktif Plan</div>
                <div className="font-semibold">{company.subscription.plan.name}</div>
              </div>
              <Badge variant={company.subscription.status === "TRIAL" ? "warning" : "success"}>
                {company.subscription.status === "TRIAL" ? "Deneme Süresi" : "Aktif"}
              </Badge>
            </CardContent>
          </Card>
        )}

        <div className="grid md:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Araçlar</CardTitle>
              <Car className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{company._count.vehicles}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Müşteriler</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{company._count.customers}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Sözleşmeler</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{company._count.contracts}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Rezervasyonlar</CardTitle>
              <Calendar className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{company._count.reservations}</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>🎉 Hoş Geldiniz!</CardTitle>
            <CardDescription>
              Sisteminiz başarıyla kuruldu. Modüller aşamalı olarak eklenecek.
            </CardDescription>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground space-y-1">
            <p className="font-medium text-foreground mb-2">⏳ Eklenecek Modüller:</p>
            <p>• Araç yönetimi (ekle, düzenle, durum takibi)</p>
            <p>• Müşteri (cari) yönetimi</p>
            <p>• Rezervasyon ve takvim görünümü</p>
            <p>• Sözleşme ve kiralama akışı</p>
            <p>• Bakım takibi</p>
            <p>• Hasar raporları</p>
            <p>• Finans ve raporlar</p>
            <p>• Şube ve kullanıcı yönetimi</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
