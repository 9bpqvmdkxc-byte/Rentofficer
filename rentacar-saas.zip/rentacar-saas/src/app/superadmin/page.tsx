import { prisma } from "@/lib/prisma";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { signOut } from "@/lib/auth";
import { Building2, Users, CreditCard, LogOut } from "lucide-react";

export default async function SuperAdminDashboard() {
  const [companiesCount, activeSubscriptions, totalUsers, companies] = await Promise.all([
    prisma.company.count(),
    prisma.subscription.count({ where: { status: { in: ["ACTIVE", "TRIAL"] } } }),
    prisma.user.count(),
    prisma.company.findMany({
      include: {
        subscription: { include: { plan: true } },
        _count: { select: { users: true, vehicles: true } },
      },
      orderBy: { createdAt: "desc" },
      take: 10,
    }),
  ]);

  return (
    <div className="min-h-screen bg-muted/30">
      <header className="border-b bg-background">
        <div className="container flex h-16 items-center justify-between">
          <h1 className="text-xl font-bold">🛡️ Platform Admin Paneli</h1>
          <form action={async () => { "use server"; await signOut({ redirectTo: "/" }); }}>
            <Button variant="outline" size="sm" type="submit">
              <LogOut className="h-4 w-4" />
              Çıkış
            </Button>
          </form>
        </div>
      </header>

      <div className="container py-8 space-y-6">
        <div className="grid md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Toplam Firma</CardTitle>
              <Building2 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{companiesCount}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Aktif Abonelik</CardTitle>
              <CreditCard className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{activeSubscriptions}</div>
            </CardContent>
          </Card>
          <Card>
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium">Toplam Kullanıcı</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold">{totalUsers}</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Firmalar</CardTitle>
            <CardDescription>Son kaydolan firmalar</CardDescription>
          </CardHeader>
          <CardContent>
            {companies.length === 0 ? (
              <p className="text-sm text-muted-foreground py-4 text-center">Henüz firma yok</p>
            ) : (
              <div className="space-y-3">
                {companies.map((c) => (
                  <div key={c.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <div className="font-medium">{c.name}</div>
                      <div className="text-sm text-muted-foreground">
                        /{c.slug} • {c._count.users} kullanıcı • {c._count.vehicles} araç
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {c.subscription && (
                        <Badge variant={c.subscription.status === "TRIAL" ? "warning" : "success"}>
                          {c.subscription.plan.name} ({c.subscription.status})
                        </Badge>
                      )}
                      {c.isSuspended && <Badge variant="destructive">Askıda</Badge>}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>⏳ Yakında Gelecek</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-muted-foreground space-y-1">
            <p>• Firma detayları ve yönetimi</p>
            <p>• Abonelik/paket yönetimi</p>
            <p>• Platform faturaları</p>
            <p>• Kullanım istatistikleri</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
