"use client";

import { useState, Suspense } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { Car, Loader2 } from "lucide-react";

function RegisterForm() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const planSlug = searchParams.get("plan") || "starter";
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    companyName: "",
    companySlug: "",
    adminName: "",
    email: "",
    phone: "",
    password: "",
    passwordConfirm: "",
  });

  function slugify(text: string) {
    const trMap: Record<string, string> = {
      ç: "c", Ç: "c", ğ: "g", Ğ: "g", ı: "i", I: "i",
      İ: "i", ö: "o", Ö: "o", ş: "s", Ş: "s", ü: "u", Ü: "u",
    };
    return text.split("").map((c) => trMap[c] || c).join("")
      .toLowerCase().trim().replace(/[^a-z0-9\s-]/g, "")
      .replace(/\s+/g, "-").replace(/-+/g, "-");
  }

  function handleCompanyNameChange(val: string) {
    setForm({ ...form, companyName: val, companySlug: slugify(val) });
  }

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    if (form.password !== form.passwordConfirm) {
      toast.error("Şifreler uyuşmuyor");
      return;
    }
    if (form.password.length < 6) {
      toast.error("Şifre en az 6 karakter olmalı");
      return;
    }

    setLoading(true);
    try {
      const res = await fetch("/api/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ...form, planSlug }),
      });

      const data = await res.json();
      if (!res.ok) {
        toast.error(data.error || "Kayıt başarısız");
        setLoading(false);
        return;
      }

      toast.success("Kayıt başarılı! Giriş yapabilirsiniz.");
      router.push("/login");
    } catch {
      toast.error("Bir hata oluştu");
      setLoading(false);
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4 py-8 bg-gradient-to-br from-primary/5 to-muted">
      <Card className="w-full max-w-2xl">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-3">
            <div className="h-12 w-12 rounded-xl bg-primary flex items-center justify-center">
              <Car className="h-7 w-7 text-primary-foreground" />
            </div>
          </div>
          <CardTitle>Ücretsiz Hesap Oluştur</CardTitle>
          <CardDescription>30 gün ücretsiz deneme süresi</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="border rounded-lg p-4 bg-muted/30">
              <h3 className="font-medium text-sm mb-3">Firma Bilgileri</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="companyName">Firma Adı *</Label>
                  <Input
                    id="companyName"
                    required
                    value={form.companyName}
                    onChange={(e) => handleCompanyNameChange(e.target.value)}
                    placeholder="ABC Rent A Car"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="slug">URL (otomatik)</Label>
                  <Input
                    id="slug"
                    required
                    value={form.companySlug}
                    onChange={(e) => setForm({ ...form, companySlug: slugify(e.target.value) })}
                    placeholder="abc-rent-a-car"
                  />
                  <p className="text-xs text-muted-foreground">
                    siteniz.com/{form.companySlug || "firma-slug"}
                  </p>
                </div>
              </div>
            </div>

            <div className="border rounded-lg p-4 bg-muted/30">
              <h3 className="font-medium text-sm mb-3">Yönetici Hesabı</h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="adminName">Ad Soyad *</Label>
                  <Input
                    id="adminName"
                    required
                    value={form.adminName}
                    onChange={(e) => setForm({ ...form, adminName: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Telefon</Label>
                  <Input
                    id="phone"
                    type="tel"
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                  />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="email">E-posta *</Label>
                  <Input
                    id="email"
                    type="email"
                    required
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="password">Şifre *</Label>
                  <Input
                    id="password"
                    type="password"
                    required
                    minLength={6}
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="passwordConfirm">Şifre Tekrar *</Label>
                  <Input
                    id="passwordConfirm"
                    type="password"
                    required
                    minLength={6}
                    value={form.passwordConfirm}
                    onChange={(e) => setForm({ ...form, passwordConfirm: e.target.value })}
                  />
                </div>
              </div>
            </div>

            <Button type="submit" className="w-full" size="lg" disabled={loading}>
              {loading && <Loader2 className="h-4 w-4 animate-spin" />}
              Hesap Oluştur
            </Button>
          </form>

          <p className="mt-4 text-center text-sm text-muted-foreground">
            Zaten hesabın var mı?{" "}
            <Link href="/login" className="text-primary hover:underline font-medium">
              Giriş yap
            </Link>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}

export default function RegisterPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center"><Loader2 className="h-6 w-6 animate-spin" /></div>}>
      <RegisterForm />
    </Suspense>
  );
}
