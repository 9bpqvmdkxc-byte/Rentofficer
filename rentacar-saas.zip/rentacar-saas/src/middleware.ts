import { auth } from "@/lib/auth";
import { NextResponse } from "next/server";

export default auth((req) => {
  const { nextUrl } = req;
  const isLoggedIn = !!req.auth;
  const userType = (req.auth?.user as any)?.userType;
  const companySlug = (req.auth?.user as any)?.companySlug;

  const path = nextUrl.pathname;

  // Public paths
  const publicPaths = ["/", "/login", "/register", "/api/auth"];
  const isPublic = publicPaths.some((p) => path === p || path.startsWith(p + "/"));

  if (isPublic) {
    // Logged in ise login/register'a girmesin
    if (isLoggedIn && (path === "/login" || path === "/register")) {
      if (userType === "superadmin") {
        return NextResponse.redirect(new URL("/superadmin", nextUrl));
      }
      if (companySlug) {
        return NextResponse.redirect(new URL(`/${companySlug}`, nextUrl));
      }
    }
    return NextResponse.next();
  }

  // Superadmin path
  if (path.startsWith("/superadmin")) {
    if (!isLoggedIn) {
      return NextResponse.redirect(new URL("/login?type=superadmin", nextUrl));
    }
    if (userType !== "superadmin") {
      return NextResponse.redirect(new URL("/login?type=superadmin", nextUrl));
    }
    return NextResponse.next();
  }

  // Company paths: /[slug]/...
  if (!isLoggedIn) {
    return NextResponse.redirect(new URL("/login", nextUrl));
  }

  if (userType === "superadmin") {
    return NextResponse.redirect(new URL("/superadmin", nextUrl));
  }

  // URL'deki slug ile kullanıcının slug'ı eşleşmeli
  const urlSlug = path.split("/")[1];
  if (urlSlug && urlSlug !== companySlug) {
    return NextResponse.redirect(new URL(`/${companySlug}`, nextUrl));
  }

  return NextResponse.next();
});

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\.).*)"],
};
