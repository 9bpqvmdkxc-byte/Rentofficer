import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import { prisma } from "./prisma";
import { z } from "zod";

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(1),
  userType: z.enum(["company", "superadmin"]),
});

export const { handlers, auth, signIn, signOut } = NextAuth({
  session: { strategy: "jwt" },
  pages: {
    signIn: "/login",
  },
  providers: [
    Credentials({
      credentials: {
        email: {},
        password: {},
        userType: {},
      },
      async authorize(credentials) {
        const parsed = loginSchema.safeParse(credentials);
        if (!parsed.success) return null;

        const { email, password, userType } = parsed.data;

        if (userType === "superadmin") {
          const admin = await prisma.superAdmin.findUnique({
            where: { email },
          });
          if (!admin || !admin.isActive) return null;
          const ok = await bcrypt.compare(password, admin.password);
          if (!ok) return null;

          await prisma.superAdmin.update({
            where: { id: admin.id },
            data: { lastLoginAt: new Date() },
          });

          return {
            id: admin.id,
            email: admin.email,
            name: admin.name,
            userType: "superadmin",
          };
        }

        // Company user login
        const user = await prisma.user.findFirst({
          where: { email, isActive: true },
          include: { company: true },
        });
        if (!user) return null;
        if (!user.company.isActive || user.company.isSuspended) return null;

        const ok = await bcrypt.compare(password, user.password);
        if (!ok) return null;

        await prisma.user.update({
          where: { id: user.id },
          data: { lastLoginAt: new Date() },
        });

        return {
          id: user.id,
          email: user.email,
          name: user.name,
          userType: "company",
          companyId: user.companyId,
          companySlug: user.company.slug,
          companyName: user.company.name,
          branchId: user.branchId,
          role: user.role,
          permissions: user.permissions,
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.userType = (user as any).userType;
        token.companyId = (user as any).companyId;
        token.companySlug = (user as any).companySlug;
        token.companyName = (user as any).companyName;
        token.branchId = (user as any).branchId;
        token.role = (user as any).role;
        token.permissions = (user as any).permissions;
      }
      return token;
    },
    async session({ session, token }) {
      if (session.user) {
        (session.user as any).id = token.sub;
        (session.user as any).userType = token.userType;
        (session.user as any).companyId = token.companyId;
        (session.user as any).companySlug = token.companySlug;
        (session.user as any).companyName = token.companyName;
        (session.user as any).branchId = token.branchId;
        (session.user as any).role = token.role;
        (session.user as any).permissions = token.permissions;
      }
      return session;
    },
  },
});
