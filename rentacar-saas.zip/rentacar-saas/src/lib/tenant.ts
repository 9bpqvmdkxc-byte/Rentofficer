/**
 * ════════════════════════════════════════════════════════════════
 *  TENANT ISOLATION (Multi-tenant güvenlik katmanı)
 * ════════════════════════════════════════════════════════════════
 *
 * Bu dosya SaaS sisteminin GÜVENLİK KALBİDİR.
 *
 * Kural: Her sorguda mutlaka companyId filtresi olmalı.
 * Bir firma ASLA başka bir firmanın verisini göremez.
 *
 * Kullanım:
 *   const ctx = await getTenantContext();
 *   const vehicles = await prisma.vehicle.findMany({
 *     where: { companyId: ctx.companyId }
 *   });
 */

import { prisma } from "./prisma";

export interface TenantContext {
  userId: string;
  companyId: string;
  branchId: string | null;
  role: string;
  permissions: string[];
}

/**
 * URL'deki slug ile oturumdaki companyId eşleşiyor mu kontrol eder
 * Eşleşmiyorsa hata fırlatır (yetkisiz erişim)
 */
export async function verifyTenantAccess(
  userId: string,
  companySlug: string
): Promise<TenantContext> {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    include: { company: true },
  });

  if (!user) {
    throw new Error("Kullanıcı bulunamadı");
  }

  if (!user.isActive) {
    throw new Error("Kullanıcı hesabı pasif");
  }

  if (user.company.slug !== companySlug) {
    throw new Error("Bu firmaya erişim yetkiniz yok");
  }

  if (!user.company.isActive || user.company.isSuspended) {
    throw new Error("Firma hesabı askıya alınmış");
  }

  return {
    userId: user.id,
    companyId: user.companyId,
    branchId: user.branchId,
    role: user.role,
    permissions: user.permissions,
  };
}

/**
 * Yardımcı: Sorgulara companyId filtresi ekler
 */
export function withCompanyScope<T extends Record<string, unknown>>(
  where: T,
  companyId: string
): T & { companyId: string } {
  return { ...where, companyId };
}

/**
 * Kullanıcının belirli bir aksiyon için yetkisi var mı?
 */
export function hasPermission(
  context: TenantContext,
  permission: string
): boolean {
  // Company admin her şeyi yapabilir
  if (context.role === "COMPANY_ADMIN") {
    return true;
  }

  // Özel yetkiler
  return context.permissions.includes(permission);
}

/**
 * Rol bazlı erişim kontrolü
 */
export function hasRole(
  context: TenantContext,
  allowedRoles: string[]
): boolean {
  return allowedRoles.includes(context.role);
}
