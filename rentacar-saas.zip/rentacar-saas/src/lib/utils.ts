import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/**
 * Tailwind class'larını birleştirmek için yardımcı fonksiyon
 * shadcn/ui bileşenlerinde kullanılır
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Para birimini formatlar
 */
export function formatCurrency(
  amount: number | string,
  currency: string = "TRY",
  locale: string = "tr-TR"
): string {
  const value = typeof amount === "string" ? parseFloat(amount) : amount;
  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency,
  }).format(value);
}

/**
 * Tarihi formatlar
 */
export function formatDate(
  date: Date | string,
  locale: string = "tr-TR"
): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat(locale, {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(d);
}

/**
 * Tarih ve saati formatlar
 */
export function formatDateTime(
  date: Date | string,
  locale: string = "tr-TR"
): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return new Intl.DateTimeFormat(locale, {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).format(d);
}

/**
 * İki tarih arasındaki gün sayısını hesaplar
 */
export function daysBetween(start: Date | string, end: Date | string): number {
  const s = typeof start === "string" ? new Date(start) : start;
  const e = typeof end === "string" ? new Date(end) : end;
  const diffTime = Math.abs(e.getTime() - s.getTime());
  return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
}

/**
 * Slug oluştur (firma URL'i için)
 * "ABC Rent A Car" → "abc-rent-a-car"
 */
export function slugify(text: string): string {
  const trMap: Record<string, string> = {
    ç: "c", Ç: "c", ğ: "g", Ğ: "g", ı: "i", I: "i",
    İ: "i", ö: "o", Ö: "o", ş: "s", Ş: "s", ü: "u", Ü: "u",
  };
  return text
    .split("")
    .map((char) => trMap[char] || char)
    .join("")
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-");
}

/**
 * Sözleşme numarası oluştur
 * "SZL" + yıl + 4 haneli sayaç → "SZL-2025-0001"
 */
export function generateContractNumber(
  prefix: string,
  counter: number,
  year: number = new Date().getFullYear()
): string {
  return `${prefix}-${year}-${counter.toString().padStart(4, "0")}`;
}
