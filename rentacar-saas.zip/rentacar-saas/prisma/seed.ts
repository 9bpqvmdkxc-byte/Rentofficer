/**
 * ════════════════════════════════════════════════════════════════
 *  SEED (İlk kurulum verileri)
 * ════════════════════════════════════════════════════════════════
 *
 * Çalıştırmak için: npm run db:seed
 *
 * Bu dosya:
 *   1. Süper admin hesabı oluşturur
 *   2. Varsayılan abonelik paketlerini oluşturur
 *   3. Demo firma ve içeriğini ekler
 */

import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🌱 Seed başlıyor...");

  // ════════════════════════════════════════════════════════════
  // 1. SÜPER ADMIN
  // ════════════════════════════════════════════════════════════
  const superAdminPassword = await bcrypt.hash("admin123", 10);
  const superAdmin = await prisma.superAdmin.upsert({
    where: { email: "admin@rentacar-saas.com" },
    update: {},
    create: {
      email: "admin@rentacar-saas.com",
      password: superAdminPassword,
      name: "Platform Admin",
    },
  });
  console.log("✅ Süper admin oluşturuldu:", superAdmin.email);

  // ════════════════════════════════════════════════════════════
  // 2. ABONELİK PAKETLERİ
  // ════════════════════════════════════════════════════════════
  await prisma.plan.upsert({
    where: { slug: "starter" },
    update: {},
    create: {
      name: "Başlangıç",
      slug: "starter",
      description: "Küçük firmalar için temel özellikler",
      monthlyPrice: 499,
      yearlyPrice: 4990,
      currency: "TRY",
      maxVehicles: 10,
      maxUsers: 3,
      maxBranches: 1,
      hasMaintenance: true,
      hasFinance: true,
      hasReports: false,
      hasDamageReport: false,
      hasApiAccess: false,
      sortOrder: 1,
    },
  });

  await prisma.plan.upsert({
    where: { slug: "professional" },
    update: {},
    create: {
      name: "Profesyonel",
      slug: "professional",
      description: "Büyüyen firmalar için gelişmiş özellikler",
      monthlyPrice: 999,
      yearlyPrice: 9990,
      currency: "TRY",
      maxVehicles: 50,
      maxUsers: 10,
      maxBranches: 3,
      hasMaintenance: true,
      hasFinance: true,
      hasReports: true,
      hasDamageReport: true,
      hasApiAccess: false,
      sortOrder: 2,
    },
  });

  await prisma.plan.upsert({
    where: { slug: "enterprise" },
    update: {},
    create: {
      name: "Kurumsal",
      slug: "enterprise",
      description: "Büyük filolar için sınırsız özellikler",
      monthlyPrice: 2499,
      yearlyPrice: 24990,
      currency: "TRY",
      maxVehicles: 500,
      maxUsers: 50,
      maxBranches: 20,
      hasMaintenance: true,
      hasFinance: true,
      hasReports: true,
      hasDamageReport: true,
      hasApiAccess: true,
      sortOrder: 3,
    },
  });
  console.log("✅ 3 abonelik paketi oluşturuldu");

  // ════════════════════════════════════════════════════════════
  // 3. DEMO FİRMA
  // ════════════════════════════════════════════════════════════
  const demoCompany = await prisma.company.upsert({
    where: { slug: "demo-rentacar" },
    update: {},
    create: {
      slug: "demo-rentacar",
      name: "Demo Rent A Car",
      legalName: "Demo Rent A Car Ltd. Şti.",
      email: "info@demo-rentacar.com",
      phone: "+90 212 555 0000",
      city: "İstanbul",
      country: "TR",
      defaultCurrency: "TRY",
      settings: {
        create: {
          contractPrefix: "SZL",
          defaultDepositAmount: 2000,
          defaultKmLimit: 250,
          extraKmPrice: 5,
        },
      },
    },
  });

  // Demo firmaya abonelik
  const professionalPlan = await prisma.plan.findUnique({
    where: { slug: "professional" },
  });

  if (professionalPlan) {
    const thirtyDaysLater = new Date();
    thirtyDaysLater.setDate(thirtyDaysLater.getDate() + 30);

    await prisma.subscription.upsert({
      where: { companyId: demoCompany.id },
      update: {},
      create: {
        companyId: demoCompany.id,
        planId: professionalPlan.id,
        status: "TRIAL",
        trialEndsAt: thirtyDaysLater,
        currentPeriodEnd: thirtyDaysLater,
      },
    });
  }

  // Demo şube
  const mainBranch = await prisma.branch.upsert({
    where: { companyId_code: { companyId: demoCompany.id, code: "IST01" } },
    update: {},
    create: {
      companyId: demoCompany.id,
      name: "İstanbul - Merkez Şube",
      code: "IST01",
      city: "İstanbul",
      country: "TR",
      isMain: true,
    },
  });

  // Demo firma admini
  const adminPassword = await bcrypt.hash("demo123", 10);
  await prisma.user.upsert({
    where: {
      companyId_email: {
        companyId: demoCompany.id,
        email: "admin@demo-rentacar.com",
      },
    },
    update: {},
    create: {
      companyId: demoCompany.id,
      branchId: mainBranch.id,
      email: "admin@demo-rentacar.com",
      password: adminPassword,
      name: "Demo Admin",
      role: "COMPANY_ADMIN",
    },
  });

  // Araç kategorileri
  const categories = ["Ekonomik", "Orta Sınıf", "SUV", "Lüks", "Ticari"];
  for (let i = 0; i < categories.length; i++) {
    await prisma.vehicleCategory.upsert({
      where: {
        companyId_name: { companyId: demoCompany.id, name: categories[i] },
      },
      update: {},
      create: {
        companyId: demoCompany.id,
        name: categories[i],
        sortOrder: i,
      },
    });
  }

  // Gider kategorileri
  const expenseCategories = ["Yakıt", "Temizlik", "Bakım", "Sigorta", "Kira", "Personel", "Diğer"];
  for (const name of expenseCategories) {
    await prisma.expenseCategory.upsert({
      where: { companyId_name: { companyId: demoCompany.id, name } },
      update: {},
      create: { companyId: demoCompany.id, name },
    });
  }

  // Ek hizmet tipleri
  const extras = [
    { name: "Bebek Koltuğu", dailyPrice: 50 },
    { name: "Navigasyon", dailyPrice: 30 },
    { name: "Ek Sürücü", dailyPrice: 75 },
    { name: "Tam Kasko", dailyPrice: 100 },
    { name: "Wifi Cihazı", dailyPrice: 40 },
  ];
  for (const extra of extras) {
    await prisma.contractExtraType.create({
      data: {
        companyId: demoCompany.id,
        name: extra.name,
        dailyPrice: extra.dailyPrice,
      },
    }).catch(() => {}); // Eğer varsa yoksay
  }

  console.log("✅ Demo firma oluşturuldu: demo-rentacar");
  console.log("");
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  console.log("🎉 Seed tamamlandı!");
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
  console.log("");
  console.log("📌 Giriş Bilgileri:");
  console.log("");
  console.log("🔹 Süper Admin:");
  console.log("   URL: http://localhost:3000/superadmin");
  console.log("   Email: admin@rentacar-saas.com");
  console.log("   Şifre: admin123");
  console.log("");
  console.log("🔹 Demo Firma Admini:");
  console.log("   URL: http://localhost:3000/demo-rentacar");
  console.log("   Email: admin@demo-rentacar.com");
  console.log("   Şifre: demo123");
  console.log("");
  console.log("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
}

main()
  .catch((e) => {
    console.error("❌ Seed hatası:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
